from game import Chess


if __name__ == '__main__':
    chess_game = Chess()
    chess_game.game()