from typing import Any, Tuple

from chessboard import Board
from chesspieces import Pawn, Piece
from piecescolor import Color


class Chess:
    def __init__(self, **kwargs: Any) -> None:
        self.current_color = Color.WHITE

    def _next_turn_color(self) -> None:
        self.current_color = Color.enemy_of(self.current_color)

    def print_color_turn(self) -> None:
        if self.current_color == Color.WHITE:
            print("It's the WHITE turn")
        else:
            print("It's the BLACK turn")

    def _check_input(
        self, board: Board, the_input: str, message: str
    ) -> Tuple[int, int]:
        try:
            row, col = map(int, the_input.split(','))
        except ValueError:
            print("Wrong input")
            the_input = input(message)
            return self._check_input(board, the_input, message)
        if (
            row < 0
            or col < 0
            or row >= board.BOARD_SIZE[0]
            or col >= board.BOARD_SIZE[1]
        ):
            print("Wrong input")
            the_input = input(message)
            return self._check_input(board, the_input, message)
        return row, col

    def _check_square_and_color(
        self, board: Board, row: int, col: int
    ) -> Piece:
        piece = board.get_square(row, col)
        if (piece is None
            or piece.color != self.current_color
            or not list(board.get_piece_moves(piece))
           ):
            if piece is None:
                print("Empty square")
            elif piece.color != self.current_color:
                print("Enemy's piece, wrong piece")
            elif not list(board.get_piece_moves(piece)):
                print("This piece can't move")
            message = "Insert the tool you want to move in this way: (row, col): "
            source = input(message)
            return self._check_square_and_color(board, *self._check_input(board, source, message))
        return piece

    def _check_destination_and_move(
        self, board: Board, source: Tuple[int, int], destination: Tuple[int, int]
    ) -> None:
        while not board.move(source, destination):
            print("Wrong destination")
            message = "Insert where you want to move the tool: (row, col): "
            destination_str = input(message)
            row, col = self._check_input(board, destination_str, message)
            destination = row, col

    def chosen_piece_moves(
        self, board: Board, piece: Piece
    ) -> str:
        moves = ", ".join(str(move) for move in board.get_piece_moves(piece))
        print(f"Valid moves for the piece: {moves}")
        return moves

    def check_check(self, board: Board) -> bool:
        king = board.get_king(color=self.current_color)
        return king.is_threatened(board)

    def _check_pawn_promotions(
        self, board: Board, piece: Piece
    ) -> None:
        if isinstance(piece, Pawn) and piece._check_promotion(board):
            print("You can promote your pawn. Choose which option you want. Insert:")
            print("1 - for a Rook\n2 - For a Knight\n3 - for a Bishop\n4 - for a queen")
            tool = piece.promote()
            row, col = piece.get_position()
            promotion_piece = tool(color=piece.color, row=row, col=col)
            board.set_square(row, col, promotion_piece)

    def game(self) -> None:
        board = Board()
        result = board.check_ended_game(self.current_color)
        while not result:
            self.print_color_turn()
            print(board)
            if self.check_check(board):
                print("Check!")

            message = "Insert the tool you want to move in this way: (row, col): "
            source = input(message)
            row, col = self._check_input(board, source, message)
            piece = self._check_square_and_color(board, row, col)

            self.chosen_piece_moves(board, piece)

            message = "Insert where you want to move the tool: (row, col): "
            destination_str = input(message)
            row, col = self._check_input(board, destination_str, message)
            destination = row, col
            self._check_destination_and_move(board, piece.get_position(), destination)

            self._check_pawn_promotions(board, piece)

            self._next_turn_color()
            result = board.check_ended_game(self.current_color)
        print(board)
        print(result)