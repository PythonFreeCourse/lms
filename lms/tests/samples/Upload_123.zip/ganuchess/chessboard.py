from __future__ import annotations

import copy
from typing import ClassVar, Iterator, List, Optional, Tuple, Union

import chesspieces
from piecescolor import Color


class Board:
    """Create and maintain the game board."""

    # Some functions below will not work well with altered board size.
    BOARD_SIZE: ClassVar[Tuple[int, int]] = (10, 11)

    def __init__(self) -> None:
        self.reset()
        self.last_piece_moved = None
        self.last_piece_moved_row = None

    def get_square(self, row: int, col: int) -> chesspieces.Piece:
        """Return the game piece by its position on board.

        If there is no piece in this position, or if the position does
        not exist - return False.
        """
        if self.is_valid_square(row, col):
            return self.board[row][col]

    def set_square(self, row: int, col: int, piece: chesspieces.Piece) -> None:
        """Place piece on board."""
        self.board[row][col] = piece

    def is_valid_square(self, row: int, column: int) -> bool:
        """Return True if square in board bounds, False otherwise."""
        row_exists = row in range(self.BOARD_SIZE[0])
        column_exists = column in range(self.BOARD_SIZE[1])
        return row_exists and column_exists

    def is_empty_square(self, square: Tuple[int, int]) -> bool:
        """Return True if square is unoccupied, False otherwise.

        An empty square is a square which has no game piece on it.
        If the square is out of board bounds, we consider it empty.
        """
        return self.get_square(*square) is None

    def _generate_back_row(self, color: int) -> List[chesspieces.Piece]:
        """Place player's first row pieces on board."""
        row_by_color = {Color.BLACK: 0, Color.WHITE: self.BOARD_SIZE[0] - 1}
        row = row_by_color[color]
        order_reverse = 2  # Check if the back line needs to be reversed
        if color == Color.WHITE:
            order_reverse = 1

        order = [chesspieces.Rook, chesspieces.Knight, chesspieces.Camel, chesspieces.Camel, 
                chesspieces.Wildebeest, chesspieces.Queen, chesspieces.King, chesspieces.Bishop,
                chesspieces.Bishop, chesspieces.Knight, chesspieces.Rook][::(-1) ** order_reverse]
    
        params = {'color': color, 'row': row}
        return [order[i](col=i, **params) for i in range(self.BOARD_SIZE[1])]

    def _generate_pawns_row(self, color: int) -> List[chesspieces.Pawn]:
        """Place player's pawns row on board."""
        row_by_color = {Color.BLACK: 1, Color.WHITE: self.BOARD_SIZE[0] - 2}
        row = row_by_color[color]
        params = {'color': color, 'row': row}
        return [chesspieces.Pawn(col=i, **params) for i in range(self.BOARD_SIZE[1])]

    def get_king(self, color: int) -> chesspieces.King:
        """Return the player's king."""
        for row in self.board:
            for square in row:
                if isinstance(square, chesspieces.King) and square.color == color:
                    return square

    def get_rooks(self, color: int) -> Iterator[chesspieces.Rook]:
        """Yield the player's rooks."""
        for piece in self.get_pieces(color):
            if isinstance(piece, chesspieces.Rook):
                yield piece

    def get_pieces(self, color: Optional[int] = None) -> Iterator[chesspieces.Piece]:
        """Yield the player's pieces.

        If color is unspecified (None), yield all pieces on board.
        """
        for row in self.board:
            for square in row:
                if square is not None and (color in (None, square.color)):
                    yield square

    def get_piece_moves(self, piece: chesspieces.Piece) -> Iterator[Tuple[int, int]]:
        """Yield all the piece's valid moves."""
        for move in piece.get_valid_moves(self):
            if not piece.check_king_threatened(self, move):
                yield move

    def get_all_boards_moves(self, color: int) -> Iterator[Board]:
        """Yield the player's valid boards after each move."""
        for piece in self.get_pieces(color):
            for move in piece.get_valid_moves(self):
                if not piece.check_king_threatened(self, move):
                    board_copy = copy.deepcopy(self)
                    board_copy.move(piece.get_position(), move)
                    if (
                        isinstance(piece, chesspieces.Pawn)
                        and piece._check_promotion(self)
                    ):
                        for option in piece.PROMOTIONS:
                            row, col = piece.get_position()
                            new_piece = option(color=piece.color, row=row, col=col)
                            board_copy.set_square(row, col, new_piece)
                            yield board_copy
                    else:
                        yield board_copy

    def check_ended_game(self, color: int) -> Union[str, bool]:
        """Check if the game has ended."""
        valid_moves = list(self.get_all_boards_moves(color))
        if not valid_moves:
            if self.get_king(color).is_threatened(self):
                return 'Check-Mate'
            return 'Pat'
        return False

    def reset(self) -> None:
        """Set traditional board and pieces in initial positions."""
        self.board: List[List[Union[chesspieces.Piece, None]]] = [
            self._generate_back_row(Color.BLACK),
            self._generate_pawns_row(Color.BLACK),
            [None] * self.BOARD_SIZE[1],
            [None] * self.BOARD_SIZE[1],
            [None] * self.BOARD_SIZE[1],
            [None] * self.BOARD_SIZE[1],
            [None] * self.BOARD_SIZE[1],
            [None] * self.BOARD_SIZE[1],
            self._generate_pawns_row(Color.WHITE),
            self._generate_back_row(Color.WHITE),
        ]

    def move(self, source: Tuple[int, int], destination: Tuple[int, int]) -> bool:
        """Move a piece from its place to a designated location."""
        piece = self.get_square(*source)
        piece_row = piece.row
        is_moved = piece.move(board=self, destination=destination)
        if is_moved:
            self.last_piece_moved_row = piece_row
            self.last_piece_moved = piece
        return is_moved

    def __str__(self) -> str:
        """Return current state of the board for display purposes."""
        printable = "   " + "  ".join(str(i) for i in range(len(self.board[0]))) + "\n"
        for row_index, row in enumerate(self.board):
            printable += str(row_index) + " "
            for col in row:
                if col is None:
                    printable = printable + " ▭ "
                else:
                    printable = printable + f" {col} "
            printable = printable + '\n'
        return printable