from __future__ import annotations

from abc import ABC, abstractmethod
import copy
from typing import Any, ClassVar, Dict, Iterator, Set, Tuple, Type

import chessboard
from piecescolor import Color


class Piece(ABC):
    """Represent a general chess piece."""

    def __init__(self, color: int, row: int, col: int, **kwargs: Any) -> None:
        self.color = color
        self.row = row
        self.col = col
        self.moves_num = 0
        self.directions: Set[Tuple[int, int]] = set()

    def is_possible_target(self, board: chessboard.Board, target: Tuple[int, int]) -> bool:
        """Return True if the move is legal, False otherwise.

        A move is considered legal if the piece can move from its
        current location to the target location.
        """
        is_target_valid = board.is_valid_square(*target)
        is_empty_square = board.is_empty_square(target)
        is_hitting_enemy = self.is_enemy(board.get_square(*target))
        return is_target_valid and (is_empty_square or is_hitting_enemy)

    @abstractmethod
    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        """Yield the valid target positions the piece can travel to."""
        pass

    def get_position(self) -> Tuple[int, int]:
        """Return piece current position."""
        return self.row, self.col

    def is_enemy(self, piece: Piece) -> bool:
        """Return if the piece belongs to the opponent."""
        if piece is None:
            return False
        return piece.color != self.color

    def check_king_threatened(
        self, board: chessboard.Board, destination: Tuple[int, int]
    ) -> bool:
        """Return if the king is threatened after doing the move."""
        board_copy = copy.deepcopy(board)
        board_copy.set_square(*self.get_position(), None)
        board_copy.set_square(*destination, self)
        if board_copy.get_king(color=self.color).is_threatened(board_copy):
            return True
        return False

    def move(self, board: chessboard.Board, destination: Tuple[int, int]) -> bool:
        """Change piece position on the board.

        Return True if the piece's position has successfully changed.
        Return False otherwise.
        """
        if not self.is_possible_target(board, destination):
            return False
        if destination not in self.get_valid_moves(board):
            return False
        if self.check_king_threatened(board, destination):
            return False

        board.set_square(*self.get_position(), None)
        board.set_square(*destination, self)
        self.moves_num += abs(self.row - destination[0]) + abs(self.col - destination[1])
        self.row, self.col = destination
        return True

    def get_squares_threatens(self, board: chessboard.Board) -> Iterator[Tuple[int, int]]:
        """Get all the squares which this piece threatens.

        This is usually just where the piece can go, but sometimes
        the piece threat squares which are different than the squares
        it can travel to.
        """
        for move in self.get_valid_moves(board):
            yield move

    @abstractmethod
    def __str__(self) -> str:
        pass


class WalksDiagonallyMixin(Piece):
    """Define diagonal movement on the board.

    This mixin should be used only in a Piece subclasses.
    Its purpose is to add possible movement directions to a specific
    kind of game piece.
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.directions.update({(-1, -1), (1, -1), (-1, 1), (1, 1)})


class WalksStraightMixin(Piece):
    """Define straight movement on the board.

    This mixin should be used only in a Piece subclasses.
    Its purpose is to add possible movement directions to a specific
    kind of game piece.
    """

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.directions.update({(0, -1), (-1, 0), (1, 0), (0, 1)})


class WalksMultipleStepsMixin(Piece):
    """Define a same-direction, multiple-step movement on the board.

    This mixin should be used only on a Piece subclasses.
    Its purpose is to allow a piece to travel long distances based on a
    single-step pattern.

    For example, the bishop can move diagonally up to 7 squares per
    turn (in an orthodox chess game). This mixin allows it if the
    `directions` property is set to the 4 possible diagonal steps. It
    does so by overriding the get_valid_moves method and uses the
    instance `directions` property to determine the possible step for
    the piece.
    """

    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        """Yield the valid target positions the piece can travel to."""
        for row_change, col_change in self.directions:
            steps = 1
            stop_searching_in_this_direction = False
            while not stop_searching_in_this_direction:
                new_row = self.row + row_change * steps
                new_col = self.col + col_change * steps
                target = (new_row, new_col)
                is_valid_target = self.is_possible_target(board, target)
                if is_valid_target:
                    yield target
                    steps = steps + 1
                    is_hit_enemy = self.is_enemy(board.get_square(*target))
                if not is_valid_target or (is_valid_target and is_hit_enemy):
                    stop_searching_in_this_direction = True


class Bishop(WalksDiagonallyMixin, WalksMultipleStepsMixin, Piece):
    """A classic Bishop chess piece.

    The bishop moves any number of blank squares straight.
    """
    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♗'
        return '♝'


class Rook(WalksStraightMixin, WalksMultipleStepsMixin, Piece):
    """A classic Rook chess piece.

    The rook moves any number of blank squares straight.
    """
    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♖'
        return '♜'


class Queen(
    WalksStraightMixin, WalksDiagonallyMixin, WalksMultipleStepsMixin, Piece,
):
    """A classic Queen chess piece.

    The queen moves any number of blank squares straight or diagonally.
    """
    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♕'
        return '♛'


class Knight(Piece):
    """A classic Knight chess piece.

    Can travel to the nearest square not on the same rank, file, or
    diagonal. It is not blocked by other pieces: it jumps to the new
    location.
    """
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.directions.update({
            (-2, 1), (-1, 2), (1, 2), (2, 1),  # Upper part
            (-2, -1), (-1, -2), (1, -2), (2, -1),  # Lower part
        })

    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        super().get_valid_moves(board, **kwargs)
        for add_row, add_col in self.directions:
            target = (add_row + self.row, add_col + self.col)
            if self.is_possible_target(board, target):
                yield target

    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♘'
        return '♞'


class Pawn(Piece):
    """A classic Pawn chess piece.

    A pawn moves straight forward one square, if that square is empty.
    If it has not yet moved, a pawn also has the option of moving two
    squares straight forward, provided both squares are empty.
    Pawns can only move forward.

    A pawn can capture an enemy piece on either of the two squares
    diagonally in front of the pawn. It cannot move to those squares if
    they are empty, nor to capture an enemy in front of it.

    A pawn can also be involved in en-passant or in promotion, which is
    yet to be implemented on this version of the game.
    """
    DIRECTION_BY_COLOR: ClassVar[Dict[int, int]] = {
        Color.BLACK: 1, Color.WHITE: -1
    }
    PROMOTIONS: ClassVar[Dict[str, Type[Piece]]] = {"1": Rook, "2": Knight,
                                                    "3": Bishop, "4": Queen}

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.forward = self.DIRECTION_BY_COLOR[self.color]

    def _get_regular_walk(self) -> Tuple[int, int]:
        """Return position after a single step forward."""
        return self.row + self.forward, self.col

    def _get_double_walk(self) -> Tuple[int, int]:
        """Return position after a double step forward."""
        src_row, src_col = self.get_position()
        return (src_row + self.forward * 2, src_col)

    def _get_triple_walk(self) -> Tuple[int, int]:
        """Return position after a triple step forward."""
        src_row, src_col = self.get_position()
        return (src_row + self.forward * 3, src_col)

    def _get_diagonal_walks(self) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        """Returns position after a diagonal move.

        This only happens when hitting an enemy.
        It could also happen on "en-passant", which is
        unimplemented feature for now.
        """
        src_row, src_col = self.get_position()
        return (
            (src_row + self.forward, src_col + 1),
            (src_row + self.forward, src_col - 1),
        )

    def is_possible_target(
        self, board: chessboard.Board, target: Tuple[int, int]
    ) -> bool:
        """Return True if the Pawn's move is legal, False otherwise.

        This one is a bit more complicated than the usual case.
        Pawns can only move forward. They also can move two ranks
        forward if they have yet to move. Not like the other pieces,
        pawns can't hit the enemy using their regular movement. They
        have to hit it diagonally, and can't take a step forward if the
        enemy is just in front of them.
        """
        is_valid_move = board.is_valid_square(*target)
        is_step_forward = (
            board.is_empty_square(target)
            and target == self._get_regular_walk()
        )
        is_valid_double_step_forward = (
            board.is_empty_square(target)
            and self.moves_num <= 1
            and target == self._get_double_walk()
            and self.is_possible_target(board, self._get_regular_walk())
        )
        is_valid_triple_step_forward = (
            board.is_empty_square(target)
            and not self.moves_num
            and target == self._get_triple_walk()
            and self.is_possible_target(board, self._get_double_walk())
        )
        is_hitting_enemy = (
            self.is_enemy(board.get_square(*target))
            and target in self._get_diagonal_walks()
        )
        is_en_passant = self._en_passant_check(board, target)
        return is_valid_move and (
            is_step_forward or is_valid_double_step_forward or is_valid_triple_step_forward
            or is_hitting_enemy or is_en_passant
        )

    def get_squares_threatens(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        """Get all the squares which the pawn can attack."""
        for square in self._get_diagonal_walks():
            if board.is_valid_square(*square):
                yield square

    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        """Yield the valid target positions the piece can travel to.

        The Pawn case is a special one - see is_possible_target's
        documentation for further details.
        """
        targets = (
            self._get_regular_walk(),
            self._get_double_walk(),
            self._get_triple_walk(),
            *self._get_diagonal_walks(),
        )
        for target in targets:
            if self.is_possible_target(board, target):
                yield target

    def _en_passant_check(
        self, board: chessboard.Board, target: Tuple[int, int]
    ) -> bool:
        """Return if the target is a special en-passant move."""
        position = self.row, target[-1]
        square = board.get_square(*position)
        return (
            target in self._get_diagonal_walks()
            and self.is_enemy(square)
            and isinstance(square, Pawn)
            and square == board.last_piece_moved
            and abs(self.row - board.last_piece_moved_row) >= 2
        )

    def _check_promotion(self, board: chessboard.Board) -> bool:
        """Check if the pawn has reached his last row."""
        if self.row == 0 or self.row == board.BOARD_SIZE[0] - 1:
            return True
        return False

    def promote(self) -> Type[Piece]:
        """Return which promotion the user chose."""
        try:
            user_input = input("Insert your input: ")
            return self.PROMOTIONS[user_input]
        except KeyError:
            print("Wrong input")
            return self.promote()

    def move(self, board: chessboard.Board, destination: Tuple[int, int]) -> bool:
        is_en_passant = self._en_passant_check(board, destination)
        moved = super().move(board, destination)
        if moved and is_en_passant:
            position = self.row - self.forward, self.col
            board.set_square(*position, None)
        return moved

    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♙'
        return '♟'


class Camel(Piece):
    """A classic Camel chess piece.

    Can travel to the nearest square not on the same rank, file, or
    diagonal. It is not blocked by other pieces: it jumps to the new
    location.
    """
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.directions.update({
            (-3, 1), (-1, 3), (1, 3), (3, 1),  # Upper part
            (-3, -1), (-1, -3), (1, -3), (3, -1),  # Lower part
        })

    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        super().get_valid_moves(board, **kwargs)
        for add_row, add_col in self.directions:
            target = (add_row + self.row, add_col + self.col)
            if self.is_possible_target(board, target):
                yield target

    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '⛀'
        return '⛂'


class Wildebeest(Knight, Camel, Piece):
    """A classic Wildebeest chess piece.

    Can travel to the nearest square not on the same rank, file, or
    diagonal. It is not blocked by other pieces: it jumps to the new
    location.
    """
    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)

    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '⛁'
        return '⛃'


class King(WalksStraightMixin, WalksDiagonallyMixin, Piece):
    """A classic King chess piece.

    Can travel one step, either diagonally or straight.
    It cannot travel to places where he will be threatened.
    """
    def move(self, board: chessboard.Board, destination: Tuple[int, int]) -> bool:
        castling_options = list(self.castling(board))
        valid_castling = destination in map(lambda item: item[0], castling_options)
        valid = super().move(board, destination)
        if valid and valid_castling:
            for king_target, one_rook, rook_target in castling_options:
                if king_target == destination:
                    board.set_square(*one_rook.get_position(), None)
                    board.set_square(*rook_target, one_rook)
                    one_rook.row, one_rook.col = rook_target
                    one_rook.moves_num = 3
        return valid

    def _get_threatened_squares(
        self, board: chessboard.Board
    ) -> Iterator[Tuple[int, int]]:
        """Yield positions in which the king will be captured."""
        enemy = Color.enemy_of(self.color)
        for piece in board.get_pieces(color=enemy):
            for move in piece.get_squares_threatens(board):
                yield move

    def is_threatened(self, board: chessboard.Board) -> bool:
        """Return if the king is threatend."""
        return super().get_position() in self._get_threatened_squares(board)

    def is_possible_target(
        self, board: chessboard.Board, target: Tuple[int, int]
    ) -> bool:
        """Return True if the king's move is legal, False otherwise.

        The king should not move to a square that the enemy threatens.
        """
        is_regular_valid = super().is_possible_target(board, target)
        threatened_squares = self._get_threatened_squares(board)
        return is_regular_valid and target not in threatened_squares

    def get_valid_moves(
        self, board: chessboard.Board, **kwargs: Any,
    ) -> Iterator[Tuple[int, int]]:
        super().get_valid_moves(board, **kwargs)
        for add_row, add_col in self.directions:
            target = (add_row + self.row, add_col + self.col)
            if self.is_possible_target(board, target):
                yield target
        for target, _, _ in self.castling(board):
            yield target

    def get_squares_threatens(
        self, board: chessboard.Board
    ) -> Iterator[Tuple[int, int]]:
        """Get all the squares that this piece may move to.

        This method is especially useful to see if other kings fall
        into this piece's territory. To prevent recursion, this
        function returns all squares we threat even if we can't go
        there.

        For example, take a scenario where the White Bishop is in B2,
        and the Black King is in B3. The White King is in D3, but it is
        allowed to go into C3 to threaten the black king if the white
        bishop protects it.
        """
        for direction in self.directions:
            row, col = self.get_position()
            row = row + direction[0]
            col = col + direction[1]
            if board.is_valid_square(row, col):
                yield (row, col)

    def castling(
        self, board: chessboard.Board
    ) -> Iterator[Tuple[Tuple[int, int], Rook, Tuple[int, int]]]:
        """Yield the possible castling options."""
        if not self.moves_num:  # The king can't move before
            for one_rook in board.get_rooks(self.color):
                col_difference = one_rook.col - self.col
                direction = col_difference // abs(col_difference)
                if (
                    not one_rook.moves_num  # The rook can't move before
                    and self.row == one_rook.row  # For coronation situation
                    and self._check_squares_for_castling(board, col_difference, direction)  # Only empty squares
                ):                                              # and the king is not threatened during the castling
                    king_target = (self.row, self.col + direction * 2)
                    rook_target = (self.row, self.col + direction)
                    yield king_target, one_rook, rook_target

    def _check_squares_for_castling(
        self, board: chessboard.Board, col_difference: int, direction: int
    ) -> bool:
        """Check if the castling can be done.

        Check that the king is not threatened.
        Check also that there are only empty squares between the king and a rook.
        """
        if self._check_threatened_castling(board, direction):
            return False
        for square_index in range(direction, col_difference, direction):
            target = (self.row, self.col + square_index)
            if not board.is_empty_square(target):
                return False
        return True

    def _check_threatened_castling(
        self, board: chessboard.Board, direction: int
    ) -> bool:
        """Check if the king is threatened during the castling event."""
        threatened_squares = self._get_threatened_squares(board)
        for add_col in range(direction, direction * 3, direction):
            target = (self.row, self.col + add_col)
            if target in threatened_squares:
                return True
        return False

    def __str__(self) -> str:
        if self.color == Color.WHITE:
            return '♔'
        return '♚'