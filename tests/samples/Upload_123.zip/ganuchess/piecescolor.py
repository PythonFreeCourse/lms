from typing import ClassVar


class Color:
    """Describe the game pieces' color"""
    BLACK: ClassVar[int] = 0
    WHITE: ClassVar[int] = 1

    @staticmethod
    def enemy_of(color: int) -> int:
        """Return the opponent color."""
        if color == Color.BLACK:
            return Color.WHITE
        return Color.BLACK