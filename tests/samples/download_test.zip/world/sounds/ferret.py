def make_sound():
    print('Trtrtrtrtrtrtrtr')