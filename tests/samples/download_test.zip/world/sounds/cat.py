def make_sound():
    print('Meow')