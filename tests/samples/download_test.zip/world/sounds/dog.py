def make_sound():
    print('Wuf')