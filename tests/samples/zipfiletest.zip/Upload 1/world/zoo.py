from sounds import cat, dog


if __name__ == '__main__':
    cat.make_sound()
    dog.make_sound()